import numpy as np
from scipy.optimize import minimize
import time

# ------------------------- 正向运动学工具函数 -------------------------
def dh_matrix(theta, alpha, a, d):
    """生成改进DH参数对应的齐次变换矩阵"""
    ct = np.cos(theta)
    st = np.sin(theta)
    ca = np.cos(alpha)
    sa = np.sin(alpha)
    return np.array([
        [ct, -st, 0, a],
        [st * ca, ct * ca, -sa, -sa * d],
        [st * sa, ct * sa, ca, ca * d],
        [0, 0, 0, 1]
    ])

def fkine(dh_params, q):
    """计算正向运动学"""
    T = np.eye(4)
    for i in range(len(dh_params)):
        theta, alpha, a, d = dh_params[i]
        theta_val = theta + q[i]
        Ti = dh_matrix(theta_val, alpha, a, d)
        T = T @ Ti
    return T

# ------------------------- 逆运动学核心算法 -------------------------
def ikunc(dh_params, T_target, q_guess, base_offset, tool_offset, max_iter=100, tol=1e-6):
    """数值逆运动学优化求解"""
    reach = sum([abs(a) for _, _, a, _ in dh_params]) + sum([abs(d) for _, _, _, d in dh_params])
    omega = np.diag([1, 1, 1, 3 / reach])

    def objective(q):
        T_current = base_offset @ fkine(dh_params, q) @ tool_offset
        error_matrix = np.linalg.inv(T_target) @ T_current - np.eye(4)
        weighted_error = error_matrix @ omega
        return np.sum(weighted_error ** 2)

    bounds = [
        (np.deg2rad(-90), np.deg2rad(90)),
        (np.deg2rad(0), np.deg2rad(180)),
        (np.deg2rad(-180), np.deg2rad(0)),
        (np.deg2rad(-90), np.deg2rad(90))
    ]

    result = minimize(objective, q_guess,
                     method='SLSQP',
                     bounds=bounds,
                     options={'maxiter': max_iter, 'ftol': tol})

    if not result.success:
        print(f"优化警告: {result.message}, 最终误差: {result.fun:.6f}")
    return result.x

# ------------------------- 模拟执行函数 -------------------------
def simulate_movement(cmd, index):
    """模拟机械臂运动过程"""
    print(f"[模拟] 正在执行第{index}个点: {cmd.strip()}")
    print(f"[模拟] 运动进行中... (耗时1秒)")
    time.sleep(1)
    print("[模拟] 运动完成信号接收 [MOVE_FINISH]")
    return True

# ------------------------- 主程序 -------------------------
if __name__ == "__main__":
    try:
        # 输入目标点坐标
        print("请输入起始点和目标点的坐标（单位：米）")
        points = []

        # 输入起始点及生成抬笔点
        print("=== 起始点（笔筒底部）===")
        x1 = float(input("x1: "))
        y1 = float(input("y1: "))
        z1 = float(input("z1: "))
        points.append((x1, y1, z1))           # 原始点
        points.append((x1, y1, z1*2))    # 抬笔点（Z+5cm）

        # 输入目标点及生成放笔点
        print("\n=== 目标点（笔筒顶部）===")
        x3 = float(input("x3: "))
        y3 = float(input("y3: "))
        points.append((x3, y3, z1*2))    # 目标点
        points.append((x3, y3, z1))           # 放笔点（Z-5cm）

        # 机械臂参数配置
        dh_params = [
            [0, 0, 0, 0],
            [0, np.pi/2, 0, 0],
            [np.pi - np.arctan(35.5/82.7), 0, 0.09, 0],
            [np.arctan(35.5/82.7), 0, 0.09, 0]
        ]
        base_offset = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 1, 0.08],
            [0, 0, 0, 1]
        ])
        tool_offset = np.array([
            [1, 0, 0, 0.011],
            [0, 1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

        # 生成控制指令
        commands = []
        q_prev = np.zeros(4)
        for idx, (x, y, z) in enumerate(points):
            # 计算目标位姿
            theta_1 = np.arctan2(-y, -x)
            Tc4 = np.array([
                [-np.cos(theta_1), -np.sin(theta_1), 0, 0.011],
                [0, 0, -1, 0],
                [np.sin(theta_1), -np.cos(theta_1), 0, 0],
                [0, 0, 0, 1]
            ])
            Tcw = np.array([[1, 0, 0, x], [0, 1, 0, y], [0, 0, 1, z], [0, 0, 0, 1]])

            T40 = np.linalg.inv(base_offset) @ Tcw @ np.linalg.inv(Tc4)
            T5w = base_offset @ T40 @ tool_offset

            # 逆运动学求解
            q_sol = ikunc(dh_params, T5w, q_prev, base_offset, tool_offset)
            q_prev = q_sol

            # 转换为舵机角度
            converted = [
                np.degrees(q_sol[0]) + 95,
                np.degrees(q_sol[1]),
                np.degrees(q_sol[2]) + 180,
                -np.degrees(q_sol[3]) + 90
            ]

            # 显示详细计算结果
            print(f"\n=== 点{idx+1}计算结果 ===")
            print(f"笛卡尔坐标: ({x:.3f}, {y:.3f}, {z:.3f})m")
            print(f"关节弧度解: {np.round(q_sol, 4)}")
            print(f"舵机指令(度): {np.round(converted, 1)}")

            # 角度校验
            valid = True
            for i, angle in enumerate(converted):
                if not (0 <= angle <= 180):
                    print(f"错误：关节{i+1}角度超限: {angle:.1f}°")
                    valid = False
            if not valid:
                raise ValueError("角度参数错误")

            # 生成指令
            cmd = f"#{converted[0]:.0f},{converted[1]:.0f},{converted[2]:.0f},{converted[3]:.0f}!"
            commands.append(cmd)
            print(f"生成指令: {cmd}")

        # 模拟执行过程
        print("\n=== 开始模拟运动 ===")
        for i, cmd in enumerate(commands):
            success = simulate_movement(cmd, i+1)

            if success:
                print(f"第{i+1}个点执行成功")
                # 特殊等待点模拟
                if i == 1 or i == 2:
                    print("[等待] 3秒稳定时间...")
                    time.sleep(3)
            else:
                raise RuntimeError("运动执行失败")

        print("\n=== 模拟完成 ===")
        print("所有轨迹点已成功执行！笔已转移至目标位置。")

    except Exception as e:
        print(f"发生错误: {str(e)}")